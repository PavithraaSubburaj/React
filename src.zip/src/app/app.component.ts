import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { EMPTY } from 'rxjs';
import { tap, distinctUntilChanged, switchMap, startWith } from 'rxjs/operators';






interface Address {
  street: string;
  city: string;
  country: string;
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  public isSameAddressControl: FormControl = new FormControl(false);
  
    public addresses: FormGroup = this.fb.group({
      TemporaryAddress: this.fb.group({
        street: '',
        city: '',
        country: ''
      }),
      PermanentAddress: this.fb.group({
        street: '',
        city: '',
        country: ''
      })
    });
    constructor(private fb: FormBuilder) { }
    
      ngOnInit() {
        this.isSameAddressControl
          .valueChanges
          .pipe(
            distinctUntilChanged(),
            switchMap(isSameAddress => {
              if (isSameAddress) {
                return this.addresses
                  .get('TemporaryAddress')
                  .valueChanges
                  .pipe(
           
                    startWith(this.addresses.get('TemporaryAddress').value),
                    tap(value =>
                    
                      this.addresses
                        .get('PermanentAddress')
                        .setValue(value)
                    )
                  )
              } else {
                this.addresses
                  .get('PermanentAddress')
                  .reset();
    
                return EMPTY;
              }
            })
           
          )
          .subscribe();
      }
}
